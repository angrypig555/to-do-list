# to-do-list
A to do list in textual

Currently it is not reccomended to use the package as it is unfinished ant its always being improved.
Required dependencies: textual, rich, python3
Runs on any OS, tested on ubuntu.
