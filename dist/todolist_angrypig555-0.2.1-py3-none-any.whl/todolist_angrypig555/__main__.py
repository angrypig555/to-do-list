from .main import application

if __name__ == "__main__":
    app = application()
    app.run()