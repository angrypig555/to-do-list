# to-do-list
A to do list in textual

Required dependencies: textual, rich, python3
Runs on any OS, tested on ubuntu.
