# to-do-list
A to do list in textual

Required dependencies: textual, rich, python3
Runs on any OS, tested on ubuntu.

# Changelog
v1.0.0
-Added the ability to hide buttons
-Stable release
